from functools import lru_cache

def _suggest(label):
    s = label.lower()
    if any(k in s for k in ["toilet", "faucet", "tap", "water jug", "water bottle", "shower"]):
        return "Possible water leak"
    if any(k in s for k in ["lampshade", "desk lamp", "spotlight", "monitor", "computer", "television", "fan"]):
        return "Lights/equipment left on"
    if any(k in s for k in ["trash", "bin", "garbage", "dustbin"]):
        return "Overflowing waste bin"
    return "Other / manual review"

@lru_cache(maxsize=1)
def _model():
    from transformers import pipeline
    return pipeline("image-classification", model="microsoft/resnet-50")

def inspect_image(image):
    try:
        predictions = _model()(image, top_k=3)
        best = predictions[0]
        label = best["label"].replace("_"," ").title()
        return {
            "label": label,
            "confidence": float(best["score"]),
            "suggested_issue": _suggest(best["label"]),
            "alternatives": predictions[1:],
            "note": "ResNet-50 is pretrained on general ImageNet objects, not specialist campus-issue detection. Confirm the issue manually before registering it."
        }
    except Exception as exc:
        return {
            "label": "Model unavailable",
            "confidence": None,
            "suggested_issue": "Other / manual review",
            "alternatives": [],
            "note": f"Could not load the pretrained model ({type(exc).__name__}). You can still register a manually reviewed issue; this is not a vision prediction."
        }
