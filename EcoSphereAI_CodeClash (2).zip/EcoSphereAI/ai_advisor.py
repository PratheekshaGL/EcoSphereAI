import os

def _fallback(campus, building, focus):
    b = campus["buildings"][building]
    issues = b["issues"]
    issue_text = "\n".join([f"- **{i['severity']} priority:** {i['type']} — {i['description']}" for i in issues]) or "- No open issues currently logged."
    actions = {
        "Reduce energy use": [
            "Inspect rooms with equipment reported as running unnecessarily.",
            "Compare simulated daily kWh before and after a shutdown schedule.",
            "Assign a responsible person to verify equipment shutdown at closing time."
        ],
        "Reduce water waste": [
            "Inspect taps, flush systems and visible wet areas before assuming a leak.",
            "Log a repair and compare simulated daily water use before and after the intervention.",
            "Check for recurrence during a follow-up inspection."
        ],
        "Improve waste management": [
            "Place clearly labelled bins at high-traffic locations.",
            "Separate wet waste from dry recyclable materials.",
            "Review contamination reports and adjust collection frequency."
        ],
        "Balance all sustainability goals": [
            "Prioritize high-severity issues first.",
            "Choose interventions with measurable before-and-after indicators.",
            "Assign an owner and review the outcome after implementation."
        ]
    }
    return f"""## EcoSphere AI action plan — {building}

**Current simulated status**
- Sustainability score: **{b['score']}/100**
- Energy: **{b['energy_kwh']} kWh/day**
- Water: **{b['water_l']} L/day**

**Reported issues**
{issue_text}

**Recommended next actions**
""" + "\n".join(f"{n}. {action}" for n,action in enumerate(actions[focus],1)) + """

**Digital Twin experiment**
Try one intervention in the Digital Twin and compare the simulated values before and after. Use measured campus data when available.

*This is a built-in rule-based fallback, not a live generative-AI response. Campus resource values are illustrative demo data.*"""

def generate_recommendation(campus, building, focus):
    key = os.getenv("OPENAI_API_KEY","").strip()
    if not key:
        return _fallback(campus,building,focus)
    try:
        from openai import OpenAI
        b = campus["buildings"][building]
        client = OpenAI(api_key=key)
        prompt = f"""You are a cautious campus sustainability planner. Produce a concise prioritized action plan.
Building: {building}
Goal: {focus}
Simulated data: energy {b['energy_kwh']} kWh/day; water {b['water_l']} L/day; sustainability score {b['score']}/100.
Reported issues: {b['issues']}
Label all numbers as simulated. Do not invent actual measurements. Give 3 practical actions, explain why each matters, and include a measurable follow-up metric. Be clear that image observations require human confirmation."""
        response = client.responses.create(model="gpt-4.1-mini",input=prompt)
        return response.output_text
    except Exception as exc:
        return _fallback(campus,building,focus) + f"\n\n*Live AI unavailable ({type(exc).__name__}); displayed rule-based fallback.*"
