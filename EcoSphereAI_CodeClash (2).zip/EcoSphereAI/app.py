import os
from datetime import datetime
from PIL import Image
import pandas as pd
import plotly.express as px
import streamlit as st

from vision import inspect_image
from twin import initial_campus, add_issue, apply_action, simulate_scenario
from ai_advisor import generate_recommendation

st.set_page_config(page_title="EcoSphere AI | Sustainable Campus", page_icon="🌿", layout="wide")

st.markdown("""
<style>
.stApp {background:linear-gradient(135deg,#071a1a 0%,#102a26 55%,#101d2b 100%);}
.block-container {max-width:1450px;padding-top:1.2rem;}
h1,h2,h3,p,label {color:#edf8f1;}
[data-testid="stMetric"] {background:rgba(255,255,255,.055);border:1px solid rgba(120,220,170,.2);padding:14px;border-radius:15px;}
.hero {padding:1.5rem;border:1px solid rgba(120,220,170,.25);border-radius:22px;background:linear-gradient(110deg,rgba(20,100,65,.5),rgba(12,43,52,.7));}
.muted {color:#b0c9bd;}
</style>
""", unsafe_allow_html=True)

if "campus" not in st.session_state:
    st.session_state.campus = initial_campus()
if "reports" not in st.session_state:
    st.session_state.reports = []
if "last_scan" not in st.session_state:
    st.session_state.last_scan = None
if "recommendation" not in st.session_state:
    st.session_state.recommendation = ""

campus = st.session_state.campus

with st.sidebar:
    st.markdown("## 🌿 EcoSphere AI")
    st.caption("AI-Powered Sustainable Campus")
    page = st.radio("Navigate", ["Campus Overview", "Report an Issue", "Digital Twin", "AI Action Planner"])
    st.divider()
    st.caption("Prototype mode: all building and resource values are simulated.")
    if st.button("Reset demo", use_container_width=True):
        st.session_state.campus = initial_campus()
        st.session_state.reports = []
        st.session_state.last_scan = None
        st.session_state.recommendation = ""
        st.rerun()

def status_for(score):
    if score >= 80: return "Good"
    if score >= 55: return "Needs attention"
    return "Critical"

if page == "Campus Overview":
    st.markdown("""
    <div class="hero">
      <p style="letter-spacing:2px;margin-bottom:2px;color:#9ae6bb;">COMPUTER VISION · DIGITAL TWIN · GENERATIVE AI</p>
      <h1 style="font-size:2.5rem;margin:0;">EcoSphere AI</h1>
      <p style="font-size:1.1rem;margin-top:8px;">See the issue. Simulate the impact. Choose the greener action.</p>
      <p class="muted">An interactive virtual campus that turns visible sustainability issues into prioritized, explainable actions.</p>
    </div>
    """, unsafe_allow_html=True)
    st.write("")
    buildings = campus["buildings"]
    total_issues = sum(len(b["issues"]) for b in buildings.values())
    avg_score = sum(b["score"] for b in buildings.values()) / len(buildings)
    energy = sum(b["energy_kwh"] for b in buildings.values())
    water = sum(b["water_l"] for b in buildings.values())
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Campus sustainability score", f"{avg_score:.0f}/100")
    c2.metric("Open reported issues", total_issues)
    c3.metric("Simulated daily energy", f"{energy:,.0f} kWh")
    c4.metric("Simulated daily water", f"{water:,.0f} L")
    st.subheader("Interactive campus map")
    st.caption("Select a building to inspect its simulated resource use and reported issues.")
    cols = st.columns(3)
    for i,(name,b) in enumerate(buildings.items()):
        with cols[i%3]:
            with st.container(border=True):
                st.markdown(f"### {b['emoji']} {name}")
                st.progress(max(0,min(100,b["score"]))/100)
                st.write(f"**Sustainability score:** {b['score']}/100")
                st.write(f"⚡ {b['energy_kwh']} kWh/day · 💧 {b['water_l']} L/day")
                st.write(f"Open issues: **{len(b['issues'])}**")
                if b["issues"]:
                    st.warning(" · ".join(x["type"] for x in b["issues"][-2:]))
                else:
                    st.success("No open demo issues")
    st.subheader("Resource comparison")
    df = pd.DataFrame([{"Building":n,"Energy (kWh/day)":b["energy_kwh"],"Water (L/day)":b["water_l"]} for n,b in buildings.items()])
    metric = st.selectbox("Choose resource", ["Energy (kWh/day)", "Water (L/day)"])
    fig = px.bar(df,x="Building",y=metric,color="Building",template="plotly_dark",title=f"Simulated {metric.lower()} by building")
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",showlegend=False)
    st.plotly_chart(fig,use_container_width=True)
    if st.session_state.reports:
        st.subheader("Recent reports")
        st.dataframe(pd.DataFrame(st.session_state.reports[-6:][::-1]),use_container_width=True,hide_index=True)

elif page == "Report an Issue":
    st.title("📸 Report a campus sustainability issue")
    st.write("Upload a photo, run the image model, then confirm the issue category. Image models can be wrong, so human confirmation is part of the workflow.")
    up = st.file_uploader("Upload a campus photo", type=["jpg","jpeg","png","webp"])
    left,right = st.columns([1,1])
    if up:
        img = Image.open(up).convert("RGB")
        with left:
            st.image(img,caption="Uploaded photo",use_container_width=True)
        if st.button("🔎 Inspect image with Computer Vision",type="primary"):
            with st.spinner("Running pretrained image classifier (first run may download model weights)..."):
                st.session_state.last_scan = inspect_image(img)
        scan = st.session_state.last_scan
        if scan:
            with right:
                st.subheader("Vision result")
                st.write(f"**Detected general object:** {scan['label']}")
                st.write(f"**Confidence:** {scan['confidence']:.0%}" if scan["confidence"] is not None else "**Confidence:** unavailable")
                st.caption(scan["note"])
                suggested = scan.get("suggested_issue","Other / manual review")
                choices = ["Overflowing waste bin","Possible water leak","Lights/equipment left on","Excessive waste / poor segregation","Other / manual review"]
                default_idx = choices.index(suggested) if suggested in choices else len(choices)-1
                issue_type = st.selectbox("Confirm the issue (human review)",choices,index=default_idx)
                building = st.selectbox("Campus location",list(campus["buildings"].keys()))
                severity = st.select_slider("Severity",options=["Low","Medium","High"],value="Medium")
                description = st.text_input("Short note",placeholder="e.g. Water visible near washbasin")
                if st.button("Add issue to Digital Twin",type="primary"):
                    issue = add_issue(st.session_state.campus,building,issue_type,severity,description or "Reported from uploaded image")
                    st.session_state.reports.append({
                        "Time":datetime.now().strftime("%H:%M:%S"),
                        "Building":building,
                        "Issue":issue_type,
                        "Severity":severity,
                        "Status":"Open"
                    })
                    st.success(f"Issue registered in the virtual model for {building}.")
                    st.rerun()
    else:
        st.info("Try a clear photo of a waste bin, tap, light, fan or classroom. For a reliable live demo, also keep the sample images in the project folder.")
        st.caption("The model is a general-purpose image classifier, not a specialist leak, energy or waste detector. The user-confirmed category is what updates the Digital Twin.")

elif page == "Digital Twin":
    st.title("🏙️ Campus Digital Twin")
    st.write("A software model of campus buildings, resource use and reported issues. Use actions to simulate how the campus changes.")
    buildings = campus["buildings"]
    selected = st.selectbox("Select building",list(buildings.keys()))
    b = buildings[selected]
    a,c,d = st.columns(3)
    a.metric("Sustainability score",f"{b['score']}/100")
    c.metric("Energy",f"{b['energy_kwh']} kWh/day")
    d.metric("Water",f"{b['water_l']} L/day")
    st.subheader(f"{b['emoji']} {selected}: current state")
    if b["issues"]:
        for idx,issue in enumerate(b["issues"]):
            with st.container(border=True):
                x,y = st.columns([3,1])
                x.markdown(f"**{issue['type']}** · {issue['severity']} priority")
                x.caption(issue["description"])
                if y.button("Mark resolved",key=f"resolve_{selected}_{idx}"):
                    apply_action(st.session_state.campus,selected,idx)
                    st.success("Issue resolved in the simulation.")
                    st.rerun()
    else:
        st.success("No open issues in this building's demo state.")
    st.divider()
    st.subheader("What-if simulation")
    action = st.selectbox("Proposed intervention",[
        "Switch off unused lights and equipment",
        "Repair a reported water leak",
        "Improve waste segregation and collection"
    ])
    strength = st.slider("Intervention level",10,50,20,5,format="%d%%")
    if st.button("Simulate intervention",type="primary"):
        result = simulate_scenario(st.session_state.campus,selected,action,strength)
        st.session_state.last_scenario = result
    if "last_scenario" in st.session_state:
        result = st.session_state.last_scenario
        st.markdown("### Simulated outcome")
        m1,m2,m3 = st.columns(3)
        m1.metric("Estimated daily energy saved",f"{result['energy_saved']:.1f} kWh")
        m2.metric("Estimated daily water saved",f"{result['water_saved']:.1f} L")
        m3.metric("Updated sustainability score",f"{result['score_after']}/100",f"+{result['score_after']-result['score_before']} points")
        st.caption("Illustrative scenario estimate, not measured campus performance.")

elif page == "AI Action Planner":
    st.title("✨ AI Sustainability Action Planner")
    st.write("Generate a prioritized plan based on the selected building's simulated resource data and reported issues.")
    building = st.selectbox("Building to analyze",list(campus["buildings"].keys()),key="ai_building")
    focus = st.selectbox("Planning goal",["Reduce energy use","Reduce water waste","Improve waste management","Balance all sustainability goals"])
    if st.button("Generate action plan",type="primary"):
        with st.spinner("Preparing recommendations..."):
            st.session_state.recommendation = generate_recommendation(campus,building,focus)
    if st.session_state.recommendation:
        st.markdown(st.session_state.recommendation)
    st.caption("Live generative AI requires an API key. Without one, the app provides transparent rule-based fallback recommendations.")
