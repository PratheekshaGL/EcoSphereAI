# EcoSphere AI — AI-Powered Sustainable Campus

A beginner-friendly hackathon prototype integrating:
- Computer Vision: pretrained ResNet-50 general image classifier.
- Digital Twin: simulated campus buildings, resource usage, issues, and what-if scenarios.
- Generative AI: optional OpenAI API connection with rule-based fallback.
- Dashboard: Streamlit + Plotly.

## Setup (Windows + VS Code)
1. Install Python 3.11 (64-bit) from https://www.python.org/downloads/ and tick "Add Python to PATH".
2. Extract this folder and open it in VS Code (File → Open Folder).
3. Open Terminal → New Terminal and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
```

If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

The app should open at http://localhost:8501. The first vision run may download ResNet-50 weights and requires internet. If PyTorch install fails, use Python 3.11 64-bit and consult https://pytorch.org/get-started/locally/ for a compatible CPU installation.

## Optional live Generative AI
The app works without an API key using clearly labelled rule-based recommendations. If you have an approved OpenAI API key:
1. Install dotenv: `pip install python-dotenv`
2. Create a `.env` file containing `OPENAI_API_KEY=your_key_here`
3. Add `from dotenv import load_dotenv; load_dotenv()` at the very top of `app.py` and `ai_advisor.py`, before reading environment variables.
4. Restart the app.

Never commit or share a real API key. API use may cost money. If you do not have a key, do not claim the fallback is generative AI.

## Demo flow
1. Campus Overview: show the six virtual buildings and simulated resource metrics.
2. Report an Issue: upload a campus photo and run the general image classifier.
3. Confirm the issue category manually and add it to a building.
4. Digital Twin: show the new issue and run a what-if intervention.
5. AI Action Planner: generate a plan for that building.
6. Mark an issue resolved and show the updated virtual campus.

## Limitations to disclose
- Building resource values and sustainability scores are fictional demo data.
- No DSU sensors or building-management systems are connected.
- ResNet-50 is trained for general object recognition, not specialist campus-issue detection. Image results need human confirmation.
- Live generative AI requires an API key; otherwise the application uses a rule-based fallback.
