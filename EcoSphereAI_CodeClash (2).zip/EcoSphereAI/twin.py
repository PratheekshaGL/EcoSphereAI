def initial_campus():
    return {"buildings":{
        "Academic Block A":{"emoji":"🏫","energy_kwh":420,"water_l":1850,"score":82,"issues":[]},
        "Computer Lab":{"emoji":"💻","energy_kwh":610,"water_l":420,"score":68,"issues":[
            {"type":"Lights/equipment left on","severity":"Medium","description":"Sample issue for demo: equipment may be left running after use."}]},
        "Cafeteria":{"emoji":"🍽️","energy_kwh":290,"water_l":2350,"score":61,"issues":[
            {"type":"Excessive waste / poor segregation","severity":"High","description":"Sample issue for demo: mixed waste reported near disposal station."}]},
        "Library":{"emoji":"📚","energy_kwh":350,"water_l":760,"score":88,"issues":[]},
        "Hostel Block":{"emoji":"🏢","energy_kwh":540,"water_l":3200,"score":73,"issues":[
            {"type":"Possible water leak","severity":"High","description":"Sample issue for demo: inspect washroom taps and plumbing."}]},
        "Sports Complex":{"emoji":"🏟️","energy_kwh":260,"water_l":1400,"score":79,"issues":[]}
    }}

def add_issue(campus, building, issue_type, severity, description):
    issue = {"type":issue_type,"severity":severity,"description":description}
    campus["buildings"][building]["issues"].append(issue)
    score_drop = {"Low":2,"Medium":5,"High":9}[severity]
    campus["buildings"][building]["score"] = max(20,campus["buildings"][building]["score"]-score_drop)
    return issue

def apply_action(campus, building, issue_index):
    b = campus["buildings"][building]
    if 0 <= issue_index < len(b["issues"]):
        issue = b["issues"].pop(issue_index)
        b["score"] = min(100,b["score"] + {"Low":2,"Medium":5,"High":9}[issue["severity"]])
        if issue["type"] == "Possible water leak":
            b["water_l"] = round(b["water_l"] * 0.94)
        elif issue["type"] == "Lights/equipment left on":
            b["energy_kwh"] = round(b["energy_kwh"] * 0.95)

def simulate_scenario(campus, building, action, strength_pct):
    b = campus["buildings"][building]
    before = b["score"]
    energy_saved = 0.0
    water_saved = 0.0
    if action == "Switch off unused lights and equipment":
        energy_saved = b["energy_kwh"] * strength_pct / 100
    elif action == "Repair a reported water leak":
        water_saved = b["water_l"] * strength_pct / 100
    else:
        # Waste improvements are reflected in score, not water or energy.
        pass
    score_after = min(100,before + max(1,round(strength_pct/10)))
    return {"energy_saved":energy_saved,"water_saved":water_saved,"score_before":before,"score_after":score_after}
